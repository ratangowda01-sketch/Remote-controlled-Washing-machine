#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

// Button Pins
int modeBtn  = 6;   // Button 1 - Mode Selection
int startBtn = 7;   // Button 2 - Start
int pauseBtn = 8;   // Button 3 - Pause
int stopBtn  = 9;   // Button 4 - Stop

int motorLed = 10;

// Machine State
String state = "STOPPED";

// Wash Modes
String modes[] = {"MIXED", "WHITES", "QUICK"};
int modeIndex = 0;

// LED Blink Variables (for Pause)
unsigned long previousMillis = 0;
const long interval = 500;
bool ledState = LOW;

void setup() {

  pinMode(modeBtn, INPUT_PULLUP);
  pinMode(startBtn, INPUT_PULLUP);
  pinMode(pauseBtn, INPUT_PULLUP);
  pinMode(stopBtn, INPUT_PULLUP);
  pinMode(motorLed, OUTPUT);

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0,0);
  lcd.print("Washing Machine");
  delay(2000);
  lcd.clear();
}

void loop() {

  // -------- MODE SELECTION --------
  if (digitalRead(modeBtn) == LOW) {
    modeIndex++;
    if (modeIndex > 2) modeIndex = 0;
    delay(300); // debounce
  }

  // -------- START --------
  if (digitalRead(startBtn) == LOW) {
    state = "STARTED";
  }

  // -------- PAUSE --------
  if (digitalRead(pauseBtn) == LOW) {
    state = "PAUSED";
  }

  // -------- STOP --------
  if (digitalRead(stopBtn) == LOW) {
    state = "STOPPED";
  }

  // -------- LED BEHAVIOR --------
  if (state == "STARTED") {
    digitalWrite(motorLed, HIGH);
  }
  else if (state == "STOPPED") {
    digitalWrite(motorLed, LOW);
  }
  else if (state == "PAUSED") {
    unsigned long currentMillis = millis();
    if (currentMillis - previousMillis >= interval) {
      previousMillis = currentMillis;
      ledState = !ledState;
      digitalWrite(motorLed, ledState);
    }
  }

  // -------- LCD DISPLAY --------
  lcd.setCursor(0, 0);
  lcd.print("Mode: " + modes[modeIndex] + "   ");

  lcd.setCursor(0, 1);
  lcd.print("State: " + state + "   ");
}